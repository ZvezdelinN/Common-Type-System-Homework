﻿namespace Common_Type_System_Test.Enums
{
    using System;

    public enum FacultyEnum
    {
        Informatic_Science,
        Book_keeping_Science,
        Law_Science,
        Medicine_Science,
        Pharmacy_Science,
        Tourism_Science,
        Other
    }
}

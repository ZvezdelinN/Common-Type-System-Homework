﻿namespace Common_Type_System_Test.Enums
{
    using System;

    public enum SpecialtiesEnum
    {
        Informatic,
        Book_keeping,
        Law,
        Medicine,
        Pharmacy,
        Tourism,
        Other
    }
}

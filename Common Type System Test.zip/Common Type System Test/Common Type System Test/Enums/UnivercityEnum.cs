﻿namespace Common_Type_System_Test.Models
{
    using System;

    public enum UnivercityEnum
    {
        Sofiiski_universitet,
        Vins_Varna,
        Vins_Ruse,
        TU_Varna, 
        MU_Varna,
        HMU_Varna,
        Other
    }
}

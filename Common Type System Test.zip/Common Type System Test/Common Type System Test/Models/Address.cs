﻿namespace Common_Type_System_Test.Models
{
    using System;

    public class Address
    {
        private string city;

        private int postCode;

        private string street;

        private string residentialDistrict;

        private string block;

        private string entramce;

        private int appartNum;

        public Address()
        {
        }

        public Address(
            string studCity, int studPostCode, string studResDistr) : this()
        {
            this.City = studCity;
            this.PostCode = studPostCode;
            this.ResidentalDistrict = studResDistr;
        }

        public Address(
            string studCity, int studPostCode, string studResDistr, string studBlockNumber, string studEntrance, int studAppartNum)
            : this(studCity, studPostCode, studResDistr)
        {
            this.Block = studBlockNumber;
            this.Entrance = studEntrance;
            this.AppNum = studAppartNum;
        }

        public Address(
            string studCity, int studPostCode, string studResDistr, string studStreet, string studBlockNumber, string studEntrance, int studAppartNum) : this(studCity, studPostCode, studResDistr, studBlockNumber, studEntrance, studAppartNum)
        {
            this.Street = studStreet;
        }

        public string ResidentalDistrict
        {
            get { return this.residentialDistrict; }
            set { this.residentialDistrict = value; }
        }

        public int AppNum
        {
            get { return this.appartNum; }
            set { this.appartNum = value; }
        }
        
        public string Entrance
        {
            get { return this.entramce; }
            set { this.entramce = value; }
        }

        public string Block
        {
            get { return this.block; }
            set { this.block = value; }
        }

        public string Street
        {
            get { return this.street; }
            set { this.street = value; }
        }

        public int PostCode
        {
            get { return this.postCode; }
            set { this.postCode = value; }
        }

        public string City
        {
            get { return this.city; }
            set { this.city = value; }
        }
    }
}

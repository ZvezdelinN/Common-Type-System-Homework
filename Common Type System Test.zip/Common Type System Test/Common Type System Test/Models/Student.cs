﻿using Common_Type_System_Test.Enums;

namespace Common_Type_System_Test.Models
{
    using System;
    using System.Text;

    public class Student : ICloneable, IComparable<Student>
    {
#region Fields
        private string firstName;

        private string middleNmae;

        private string lastName;

        private int ssn;

        private Address studentAddress;

        private string phoneNumber;

        private string email;

        private UnivercityEnum univercity;

        private int course;

        private SpecialtiesEnum speciality;

        private FacultyEnum faculty;
        #endregion

#region Constructors
        public Student()
        {
        }

        public Student(
            string studFName, string studMName, string studLastName) : this()
        {
            this.FirstName = studFName;
            this.MiddleName = studMName;
            this.LastName = studLastName;
        }



        public Student(
            string studFName, string studMName, string studLastName, UnivercityEnum studUnivercity, int studCourse, SpecialtiesEnum studSpecialty, FacultyEnum studFaculty) 
            : this(studFName, studMName, studLastName)
        {
            this.Univercity = studUnivercity;
            this.Course = studCourse;
            this.Speciality = studSpecialty;
            this.Faculty = studFaculty;
        }

        public Student(
            string studFName, string studMName, string studLastName, int studSsn, Address studAddress, string studPhoneNumber,
            string studEMail, UnivercityEnum studUnivercity, int studCourse, FacultyEnum studFaculty, SpecialtiesEnum studSpecialty) 
            : this(studFName, studMName, studLastName, studUnivercity, studCourse, studSpecialty, studFaculty)
        {
            this.SSN = studSsn;
            this.StudentAddress = studAddress;
            this.PhoneNumber = studPhoneNumber;
            this.EMAil = studEMail;
        }
        #endregion

#region Properties
        public FacultyEnum Faculty
        {
            get { return this.faculty; }
            set { this.faculty = value; }
        }

        public SpecialtiesEnum Speciality
        {
            get { return this.speciality; }
            set { this.speciality = value; }
        }

        public int Course
        {
            get { return this.course; }
            set { this.course = value; }
        }

        public UnivercityEnum Univercity
        {
            get { return this.univercity; }
            set { this.univercity = value; }
        }

        public string EMAil
        {
            get { return this.email; }
            set { this.email = value; }
        }

        public string PhoneNumber
        {
            get { return this.phoneNumber; }
            set { this.phoneNumber = value; }
        }

        public Address StudentAddress
        {
            get { return this.studentAddress; }
            set { this.studentAddress = value; }
        }

        public int SSN
        {
            get
            {
                return this.ssn; 
            }

            private set
            {
                if (value < 1)
                {
                    throw new NullReferenceException();
                }

                this.ssn = value;
            }
        }

        public string LastName
        {
            get 
            { 
                return this.lastName; 
            }

            private set
            {
                if (value == null)
                {
                    throw new NullReferenceException();
                }

                this.lastName = value;
            }
        }

        public string MiddleName
        {
            get 
            { 
                return this.middleNmae; 
            }

            private set
            {
                if (value == null)
                {
                    throw new NullReferenceException();
                }

                this.middleNmae = value;
            }
        }

        public string FirstName
        {
            get 
            { 
                return this.firstName;
            }

            private set 
            {
                if (value == null)
                {
                    throw new NullReferenceException();
                }

                this.firstName = value; 
            }
        }
#endregion

#region Overrides
        public override int GetHashCode()
        {
            return this.SSN ^ this.Course;
        }

        public override bool Equals(object obj)
        {
            var student = obj as Student;
            if (student == null)
            {
                return false;
            }

            if (!object.Equals(this.firstName, student.firstName))
            {
                return false;
            }

            if (this.ssn != student.ssn)
            {
                return false;
            }

            return true;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(string.Format("First name : {0}", this.FirstName));
            sb.AppendLine(string.Format("Middle name : {0}", this.MiddleName));
            sb.AppendLine(string.Format("Last name : {0}", this.LastName));
            sb.AppendLine(string.Format("Univercity : {0}", this.Univercity));
            sb.AppendLine(string.Format("Faculty : {0}", this.Faculty)); 
            sb.AppendLine(string.Format("Specialty : {0}", this.Speciality));
            sb.AppendLine(string.Format("Student number : {0}", this.SSN));
            return sb.ToString();
        }

        public static bool operator ==(Student firstStudent, Student secondStudent)
        {
            if (firstStudent == null || secondStudent == null)
            {
                return false;
            }

            if (!firstStudent.FirstName.Equals(secondStudent.FirstName))
            {
                return false;
            }

            if (firstStudent.SSN != secondStudent.SSN)
            {
                return false;
            }

            return true;
        }

        public static bool operator !=(Student firstStudent, Student secondStudent)
        {
            if (firstStudent == null || secondStudent == null)
            {
                return true;
            }

            if (!firstStudent.FirstName.Equals(secondStudent.FirstName))
            {
                return true;
            }

            if (firstStudent.SSN != secondStudent.SSN)
            {
                return true;
            }

            return false;
        }
#endregion

        public object Clone()
        {
            Student clonedStudent = (Student) this.MemberwiseClone();
            clonedStudent.Faculty = this.Faculty;
            clonedStudent.Speciality = this.Speciality;
            clonedStudent.StudentAddress = this.StudentAddress;
            return clonedStudent;
        }



        public int CompareTo(Student otherStudent)
        {
            if (this.FirstName.CompareTo(otherStudent.FirstName) == 0)
            {
                if (this.FirstName.CompareTo(otherStudent.FirstName) == 0)
                {
                    if (this.FirstName.CompareTo(otherStudent.FirstName) == 0)
                    {
                        return this.SSN.CompareTo(otherStudent.SSN);
                    }
                }
            }

            return this.FirstName.CompareTo(otherStudent.FirstName);
        }
    }
}

﻿namespace Common_Type_System_Test.Models
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Text;

    public class BitArray64 : IEnumerable<int>, IComparable 
    {
         private ulong number; 
 

         public BitArray64(ulong number) 
         { 
             this.Number = number; 
         } 
 

         public ulong Number 
         { 
             get { return number; } 
             set { number = value; } 
         } 
 

         public int this[int index] 
         { 
             get 
             { 
                 if (index < 0 || index >= 64) 
                 { 
                     throw new IndexOutOfRangeException("Invalid index."); 
                 } 
 

                 return ((int)(this.Number >> index) & 1); 
             } 
             set 
             { 
                 if (index < 0 || index >= 64) 
                 { 
                     throw new IndexOutOfRangeException("Invalid index."); 
                 } 
 

                 if (value < 0 || value > 1) 
                 { 
                     throw new ArgumentException("Invalid bit value."); 
                 } 
 

                 if (((int)(this.Number >> index) & 1) != value) 
                 { 
                     this.Number ^= ((ulong)1 << index); 
                 } 
             } 
         } 
 

         public static bool operator ==(BitArray64 firstBitArray64, BitArray64 secondBitArray64) 
         { 
             return (firstBitArray64.Equals(secondBitArray64)); 
         }


         public static bool operator !=(BitArray64 firstBitArray64, BitArray64 secondBitArray64) 
         {
             return !(firstBitArray64.Equals(secondBitArray64)); 
         } 
 

 

 

         public override string ToString() 
         { 
             StringBuilder result = new StringBuilder(); 
 

             for (int i = 0; i < 64; i++) 
             { 
                 result.Insert(0, ((this.Number >> i) & 1)); 
             } 
 

             return result.ToString(); 
         } 
 

         public override int GetHashCode() 
         { 
             return this.Number.GetHashCode(); 
         } 
 

         public override bool Equals(object obj) 
         {
             return this.Number.Equals(((BitArray64)obj).Number); 
         } 
 

         public IEnumerator<int> GetEnumerator() 
         { 
             for (int i = 0; i < 64; i++) 
             { 
                 yield return this[i]; 
             } 
         } 
 

         IEnumerator IEnumerable.GetEnumerator() 
         { 
             return this.GetEnumerator(); 
         } 
 

         public int CompareTo(object obj) 
         {
             return this.Number.CompareTo(((BitArray64)obj).Number); 
         } 
     } 
}

﻿namespace Common_Type_System_Test.Models
{
    using System;

    public class Person
    {
        private string name;

        private int? age;

        public Person(string personName, int? personAge)
        {
            this.Name = personName;
            this.Age = personAge;
        }

        public int? Age
        {
            get { return age; }
            set { age = value; }
        }
        

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public override string ToString()
        {
            string ageOrNull = "";
            if (this.age == null)
            {
                ageOrNull = "null";
            }
            else
            {
                ageOrNull = this.Age.ToString();
            }
            return string.Format("Name : {0}, Age : {1}", this.Name, ageOrNull);
        }
    }
}

﻿using Common_Type_System_Test.Models;
using Common_Type_System_Test.Enums;

namespace Common_Type_System_Test
{
    using System;
    using System.Collections.Generic;

    class Common_Type_System_Test
    {
        static void Main(string[] args)
        {
            //1.Student class
            Student newStudent = new Student("Dimitar", "Georgiev", "Bochkov", 125256, new Address("Burgas", 8023,"Vrajdebna", "12", "4", 48),  "+359895889900", "z_i_z_o@abv.bg", 
            UnivercityEnum.Vins_Varna, 4, FacultyEnum.Informatic_Science, SpecialtiesEnum.Informatic);

            Console.WriteLine(newStudent);
            
            //2.IClonable
            Student secondStudent = new Student();
            secondStudent = (Student)newStudent.Clone();

            //3.IComparable
            Student newStudent1 = new Student("Dimitar", "Nikolaev", "Stoichev", 125254, new Address("Burgas", 8023, "Vrajdebna", "12", "4", 48), "+359895779900", "z_i_z_o@abv.bg",
            UnivercityEnum.Vins_Varna, 4, FacultyEnum.Informatic_Science, SpecialtiesEnum.Informatic);

            var compareSturdents = new SortedSet<Student>();
            compareSturdents.Add(newStudent);
            compareSturdents.Add(newStudent1);

            Student newStudent2 = new Student("Dirmitar", "Georgiev", "Bochkov", 125253, new Address("Burgas", 8023, "Vrajdebna", "4", "12", 84), "+359895889900", "z_i_z_o@abv.bg",
            UnivercityEnum.Vins_Varna, 4, FacultyEnum.Informatic_Science, SpecialtiesEnum.Informatic);
            compareSturdents.Add(newStudent2);

            foreach(Student stud in compareSturdents)
            {
                Console.WriteLine(stud.FirstName + " " + stud.MiddleName + " " + stud.LastName + " " + stud.SSN);
            }

            //4.Person class
            Person person = new Person("Peter", 25);

            Console.WriteLine(person);

            //5.64 Bit array
            BitArray64 number = new BitArray64(2345); 
            
            Console.WriteLine(number); 

            number[8] = 0; 
            Console.WriteLine(number);

            BitArray64 number2 = new BitArray64(5682897);

            var hashCode = number2.GetHashCode();

            Console.WriteLine("The hash code of number2 is : {0}",hashCode);

            Console.WriteLine(number.Equals(number)); 
 
            Console.WriteLine(number == number2); 
            
            Console.WriteLine(number != number2); 

        }
    }
}
